#ifndef DISPLAY_H
#define DISPLAY_H

class Display//class definition
{
public://function prototypes
	Display();
	void flushVal(int,double,double,double,double,double,double);
	void heroStats(int,int,int,int,int,int);
private:
};
#endif