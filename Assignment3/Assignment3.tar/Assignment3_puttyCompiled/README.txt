Devon Ring 
100801142

Compiled on lambda server

To run program type make to compile
then type in the terminal ./Main


Through much testing Test 5 seems to throw my results off through the -= followed
by - spent many hours trying to resolve this to no prevail
Other than that everything seems to be working as according to the 
Assignment outline,

scribbles.cpp is just a test file I had used.

Cheers,
Devon.